from pathlib import Path
from lxml import html,etree
import json,re,base64,mimetypes,urllib.parse
root=Path(__file__).parent
out=root/'site';out.mkdir(exist_ok=True)
source=(root/'source/homepage-20261026.html').read_text()
doc=html.fromstring(source)
assets={e['url']:root/e['file'] for e in json.loads((root/'source/assets.json').read_text()) if 'file' in e}
logo=assets['/upload/uf/564/f5swvhwzev5a0tu1p87rpqsnkry0frrz.svg']
assets['/local/templates/prepcenter/images/logo.svg']=logo
assets['/upload/adwex.minified/webp/1ce/85/1ce79885de1537bc54eb08a07e61d68f.webp']=root/'assets/warehouse-aisle.jpg'
assets['/upload/adwex.minified/webp/d2e/85/d2e6a9bccc872ddf1847cd4b29383958.webp']=root/'assets/warehouse-facade.jpg'
uris={}
def data(p):
 p=str(p)
 if p not in uris:
  mt=mimetypes.guess_type(p)[0] or 'application/octet-stream';uris[p]='data:'+mt+';base64,'+base64.b64encode(Path(p).read_bytes()).decode()
 return uris[p]
def drop(e):
 if e.getparent() is not None:e.drop_tree()
for e in list(doc.xpath('//script')):
 if e.get('type')!='application/ld+json':drop(e)
for e in list(doc.xpath('//noscript|//iframe|//video|//source|//link|//base')):
 if e.tag=='link' and e.get('rel')=='canonical':continue
 drop(e)
for e in list(doc.xpath('//*[@id="cookie-banner" or @id="modal" or @id="rutubeModal"]')):drop(e)
for e in list(doc.xpath('//*[contains(@class,"floating-button")]')):
 if e.getparent() is not None:drop(e)
for e in doc.iter():
 for a in list(e.attrib):
  if a.startswith('on') or a in ['srcset','data-src','data-srcset','integrity','crossorigin']:del e.attrib[a]
for e in list(doc.xpath('//h1')):
 if not e.text_content().strip():drop(e)
for e in doc.xpath('//a'):
 e.set('href','./');e.attrib.pop('target',None);e.attrib.pop('download',None)
 e.set('class',e.get('class','').replace('getModal',''))
for e in list(doc.xpath('//button')):
 c=e.get('class','')
 if any(x in c for x in ['arrow','header__btn','mobile-menu__toggle','mobile-menu__close','mobile-menu__fbo-toggle']):continue
 e.tag='a';e.set('href','./');e.attrib.pop('type',None);e.attrib.pop('disabled',None)
for e in list(doc.xpath('//form')):
 e.tag='div';e.attrib.pop('action',None);e.attrib.pop('method',None)
 # Static emergency copy must not collect contact information.
 for inp in list(e.xpath('.//input')):
  if inp.get('type') in ['text','tel','email']:
   inp.set('disabled','disabled');inp.set('aria-disabled','true')
for e in list(doc.xpath('//img')):
 u=e.get('src','').split('?')[0]
 if u in assets:
  e.set('src',data(assets[u]));continue
 parent=e.getparent();alt=e.get('alt','')
 if parent is not None and parent.tag=='a' and 'socials__item' in parent.get('class',''):
  parent.text={'Telegram':'TG','VK':'VK','Instagram':'Instagram'}.get(alt,alt)
  parent.set('class',parent.get('class','')+' emergency-social')
 if 'case-card__media' in (parent.get('class','') if parent is not None else ''):
  e.set('src',data(logo));e.set('alt','Логотип Преп-Центра');parent.set('class',parent.get('class','')+' case-card__media--logo');continue
 drop(e)
# Restore original order after Google captured initialized carousels.
for e in doc.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," swiper-wrapper ")]'):
 e.attrib.pop('style',None)
 slides=list(e)
 if slides and all(x.get('data-swiper-slide-index') is not None for x in slides):
  for child in sorted(slides,key=lambda x:int(x.get('data-swiper-slide-index'))):e.append(child)
 for x in e:
  x.attrib.pop('style',None)
# Keep marketplace names as text when original logos are unavailable.
for e in doc.xpath('//section[contains(concat(" ",normalize-space(@class)," ")," work ")]//*[contains(concat(" ",normalize-space(@class)," ")," swiper-wrapper ")]'):
 for x in list(e):e.remove(x)
 for n in ['Wildberries','Ozon','Яндекс Маркет','ЛЭТУАЛЬ']:
  a=etree.SubElement(e,'a',{'href':'./','class':'swiper-slide emergency-marketplace'});a.text=n
# Remove empty decorative containers; maintain the content blocks from October.
for cls in ['welcome__visual','examples__images','video-card__media']:
 for e in list(doc.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," '+cls+' ")]')):drop(e)
for e in doc.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," header__btn ")]'):
 e.text='☰';e.set('aria-label','Открыть меню');e.set('type','button')
for e in doc.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," mobile-menu__close ")]'):
 e.text='×';e.set('aria-label','Закрыть меню')
# Inline styles and fonts; no resources depend on Beget.
basecss=(root/'source/archive-css.css').read_text()
style=etree.Element('style');style.set('id','restored-template-css');style.text=basecss
head=doc.find('head');head.insert(0,style)
charset=etree.Element('meta');charset.set('charset','utf-8');head.insert(0,charset)
for e in list(doc.xpath('//meta[@name="robots"]')):e.set('content','noindex, follow')
for e in list(doc.xpath('//style|//*[@style]')):
 attr='style' if e.tag!='style' else None
 text=e.get('style','') if attr else e.text or ''
 def urlreplace(m):
  u=m.group(1).strip().strip('\"\'')
  if u.startswith('data:'):return m.group(0)
  u=urllib.parse.urljoin('/local/templates/prepcenter/css/style.css',u).split('?')[0]
  return 'url("'+data(assets[u])+'")' if u in assets else 'none'
 text=re.sub(r'url\(([^)]+)\)',urlreplace,text)
 if attr:e.set('style',text)
 else:e.text=text
# Small layout adjustments for missing decorative assets and static interactions.
fix=etree.Element('style');fix.set('id','emergency-static-layout');fix.text='''
body{background:#f7f7f7}.welcome{position:relative;background:#111!important;min-height:700px}.welcome::before{content:"";position:absolute;inset:0;background-image:var(--warehouse-image);background-size:cover;background-position:center;filter:grayscale(1);opacity:.3}.welcome__inner{padding:100px 0 120px}.welcome__copy{height:auto!important;min-height:0!important;block-size:auto!important;min-block-size:0!important;position:relative}.welcome__title,.welcome__copy>.text,.welcome__copy>.welcome__btns{block-size:auto!important;min-block-size:0!important}.welcome__title{font-size:clamp(44px,5.7vw,82px);line-height:1.12}.welcome .text{max-width:1040px;margin:30px auto 0}.welcome__btns{margin-top:40px}.welcome__visual{display:none!important}.emergency-social{display:flex!important;align-items:center;justify-content:center;font-size:16px;font-weight:700;min-width:45px;height:45px;background:#ff9900;border-radius:12px;padding:0 9px;color:#111}.header__item:empty{display:none}.header__logo{max-width:310px;height:auto}.header__btn{font-size:30px;color:white}.header__compact-cta{display:none!important}.prepare__main{display:block;height:auto!important;padding:0}.prepare__holder{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px;height:auto!important;position:static!important}.prepare__item{position:static!important;transform:none!important;display:flex!important;align-items:center;gap:20px;width:100%!important;max-width:none!important;min-height:125px;background:#171717;color:white;padding:25px;border-radius:20px}.prepare__item p{font-size:20px}.prepare__black{position:static!important;transform:none!important;min-width:55px;flex-shrink:0}.prepare__black h3{color:#ff9900;font-size:46px}.prepare__item--last{grid-column:1/-1}.prepare__item--last::before{display:none}.prepare__item--last h3{font-size:30px}.services__slider,.choose__slider,.work__slider,.examples__slider{overflow-x:auto!important;scrollbar-width:thin;scroll-snap-type:x mandatory}.swiper-wrapper{transform:none!important;transition:none!important;gap:20px!important;align-items:stretch}.swiper-slide{width:calc((100% - 40px)/3)!important;min-width:calc((100% - 40px)/3)!important;flex-shrink:0;scroll-snap-align:start;margin:0!important;height:auto!important}.services__item{height:100%}.services__item h3{margin-top:10px}.choose__item{height:100%}.choose__item h3{margin-top:0}.examples__main{display:flex;flex-direction:column;padding:25px;min-height:480px}.examples__whole{padding:0}.examples__bottom{margin-top:auto}.examples__item{height:100%}.examples__wraps{display:block}.examples__images:empty{display:none}.arrows{margin-top:28px}.work .swiper-wrapper{flex-wrap:wrap}.work .swiper-slide{font-size:30px!important;font-weight:700;color:#ff9900;background:white;border-radius:20px;padding:35px;text-align:center;width:calc((100% - 60px)/4)!important;min-width:0!important}.case-card__media--logo img{object-fit:contain!important;max-height:100px;width:80%!important;margin:auto}.case-card__media--logo{display:flex;align-items:center;justify-content:center;background:#132636!important}.video-card__button{display:flex;padding:30px;background:#252525;border-radius:15px;min-height:110px;align-items:center;justify-content:center;text-align:center;color:white}.about__warehouse-photo{display:block;width:100%;height:100%;object-fit:cover}.about__wrap--warehouse::after{display:none}.form input:disabled{cursor:default}.form__item{max-width:100%}.header__list ul{overflow:visible!important}.header__list ul ul{left:100%!important;top:0!important;right:auto!important}.header__list ul li:hover>ul{visibility:visible;opacity:1}.footer__map{height:auto;min-height:0}.mobile-menu__close{font-size:36px;color:white}.floating-button,#cookie-banner{display:none!important}.services__item:before{content:"▦";display:block;color:#ff9900;font-size:42px;line-height:1;margin-bottom:18px}.prepare:before,.services:before,.work:before,.choose:before,.questions:before,.about:before,.footer:before,.examples:before,.review:before,.answer:before{background-image:none!important}.answer__bg{display:none}.header__list>li>a{white-space:nowrap}.header .container{max-width:1380px}.review__link{color:#ff9900}.header__inner{min-height:95px}.footer__logo{max-width:300px;height:auto}.footer__inner{gap:35px}.welcome__btns a{min-width:290px}.footer__text{overflow-wrap:anywhere}.case-card,.video-card{min-width:0}
@media(max-width:1200px){.header__logo{max-width:250px}.header__inner{min-height:75px}.welcome__inner{padding:70px 0 90px}.welcome{min-height:630px}.header__contacts .header__right{display:block!important}.header__contacts .header__right span{font-size:14px}.header__contacts .header__right strong{font-size:18px}.header__end{gap:14px}.welcome__btns a{min-width:0}.prepare__item p{font-size:18px}}
@media(max-width:700px){.welcome__inner{padding:60px 0 70px}.welcome{min-height:600px}.welcome__title{font-size:42px}.welcome .text{font-size:17px;line-height:1.5}.welcome__btns{gap:12px}.welcome__btns a{width:100%;min-width:0}.header__logo{max-width:190px}.header__contacts .header__right{display:none!important}.header__inner{gap:12px;min-height:68px}.prepare__holder{grid-template-columns:1fr}.prepare__item p{font-size:17px}.swiper-slide{width:100%!important;min-width:100%!important}.work .swiper-slide{width:calc(50% - 10px)!important;font-size:24px!important;padding:20px}.emergency-social{font-size:13px;height:35px;min-width:35px}.footer__inner{gap:25px}.header__list ul{max-width:100%}.examples__main{min-height:430px}.about__inner{display:flex;flex-direction:column}.about__holder--warehouse{width:100%;height:400px;display:block}.about__left{width:100%}.about__wrap--warehouse{display:block;height:300px;margin-top:24px}.title{overflow-wrap:anywhere}.header .container{padding:0 16px}.mobile-menu__list a{font-size:17px}}
'''
fix.text+='\n:root{--warehouse-image:url("'+data(root/'assets/warehouse-aisle.jpg')+'");}'
head.append(fix)
script=etree.Element('script');script.text='''
const menu=document.querySelector('.mobile-menu');
document.querySelector('.header__btn')?.addEventListener('click',()=>{menu?.classList.add('active');document.body.classList.add('hidden')});
document.querySelector('.mobile-menu__close')?.addEventListener('click',()=>{menu?.classList.remove('active');document.body.classList.remove('hidden')});
document.querySelectorAll('.mobile-menu__toggle,.mobile-menu__fbo-toggle').forEach(b=>b.addEventListener('click',()=>{let p=b.closest('li'),open=b.getAttribute('aria-expanded')!=='true';b.setAttribute('aria-expanded',String(open));p.classList.toggle('is-open',open);let s=p.querySelector('.accordion-content');if(s){s.hidden=!open;s.style.setProperty('display',open?'block':'none','important');s.style.setProperty('height',open?'auto':'0','important');s.style.setProperty('max-height',open?'none':'0','important');s.style.setProperty('overflow',open?'visible':'hidden','important');s.querySelectorAll('ul').forEach(u=>{u.hidden=!open;u.style.setProperty('display',open?'flex':'none','important')})}}));
document.querySelectorAll('section').forEach(section=>{let slider=section.querySelector('.swiper-wrapper')?.parentElement;if(!slider)return;section.querySelectorAll('.arrow').forEach(b=>b.addEventListener('click',()=>slider.scrollBy({left:(b.classList.contains('arrow--left')?-1:1)*slider.clientWidth,behavior:'smooth'})))});
'''
doc.find('body').append(script)
htmltext='<!DOCTYPE html>\n'+html.tostring(doc,encoding='unicode',method='html')
(out/'index.html').write_text(htmltext)
(out/'.nojekyll').write_text('')
(root/'source/provenance.json').write_text(json.dumps({'url':'https://prep-center.ru/','source':'Google Search Console / URL Inspection / Crawled page HTML','last_crawl_displayed':'26 октября 2026, 12:05:06','retrieved_date':'2026-11-02','original_characters':len(source),'all_anchor_links':'./','graphics_limitation':'Most source images missing in Wayback; unavailable decoration omitted; authentic warehouse photos and official logo preserved.','forms':'Static copy: no submission, CTA links go to home.'},ensure_ascii=False,indent=2))
# Exact requirements and resource independence.
check=html.fromstring(htmltext)
assert len(check.xpath('//h1'))==1
assert all(a.get('href')=='./' for a in check.xpath('//a'))
assert all(x.get('src','').startswith('data:') for x in check.xpath('//img'))
assert not check.xpath('//script[@src]|//link[@rel="stylesheet"]|//iframe')
print('Built',len(htmltext.encode()),'bytes;',len(check.xpath('//a')),'links to ./;',len(check.xpath('//img')),'embedded images')
